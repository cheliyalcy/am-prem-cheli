# AM Premium Generator — dapjisync

Website generator Alight Motion Premium gratis, aktif 1 tahun.

## Deploy ke Vercel

1. Upload folder ini ke GitHub
2. Connect repo di [vercel.com](https://vercel.com)
3. Set environment variables di Vercel dashboard:
   - `KV_REST_API_URL` — dari Vercel KV Storage
   - `KV_REST_API_TOKEN` — dari Vercel KV Storage
4. Buat Vercel KV Storage di dashboard → Storage → Create KV
5. Link KV ke project
6. Deploy!

## Halaman

| URL | Deskripsi |
|-----|-----------|
| `/` | Halaman utama — aktivasi manual |
| `/bulk` | Halaman bulk — generate 1–5 akun sekaligus |

## API Endpoints

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| POST | `/api/send-link` | Kirim magic link ke email |
| POST | `/api/verify-link` | Verifikasi magic link & apply premium |
| GET | `/api/history` | Ambil history aktivasi |
| POST | `/api/bulk` | Bulk generate akun |

### Bulk API

```bash
curl -X POST https://your-domain.vercel.app/api/bulk \
  -H "Content-Type: application/json" \
  -d '{"total": 3}'
```

## Stack

- Frontend: HTML + CSS + Vanilla JS
- Backend: Vercel Serverless Functions
- Database: Vercel KV (Redis)
- Email: akunlama.com tempmail

## Credits

Made by **dapjisync** — [t.me/dapjisync](https://t.me/dapjisync)
