const BYPASS_KEY = 'amfree_key'
const AM_API = 'https://am.dapjisync.my.id'

export default async function handler(req, res) {
  try {
    const r = await fetch(`${AM_API}/api/history`, {
      headers: { 'X-Bypass-Key': BYPASS_KEY }
    })
    const j = await r.json()
    return res.status(200).json(j)
  } catch {
    return res.status(200).json({ success: true, items: [], total: 0 })
  }
}
