const BYPASS_KEY = 'amfree_key'
const AM_API = 'https://am.dapjisync.my.id'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ success: false })

  const { email } = req.body || {}
  if (!email || !email.includes('@')) return res.status(400).json({ success: false, message: 'Email tidak valid' })

  try {
    const r = await fetch(`${AM_API}/api/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bypass-Key': BYPASS_KEY },
      body: JSON.stringify({ gmail: email })
    })
    const j = await r.json()
    return res.status(r.status).json({ success: j.success, message: j.message || 'Magic link terkirim', email })
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message })
  }
}
