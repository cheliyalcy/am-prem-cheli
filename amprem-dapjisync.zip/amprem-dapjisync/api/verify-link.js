const BYPASS_KEY = 'amfree_key'
const AM_API = 'https://am.dapjisync.my.id'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ success: false })

  const { email, magicLink, ownerMessage, deviceId } = req.body || {}
  if (!email || !magicLink) return res.status(400).json({ success: false, message: 'Email dan magic link wajib diisi' })

  try {
    const r = await fetch(`${AM_API}/api/verif`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bypass-Key': BYPASS_KEY },
      body: JSON.stringify({ gmail: email, link: magicLink })
    })
    const j = await r.json()
    if (!j.success) return res.status(400).json({ success: false, message: j.message || 'Verifikasi gagal' })

    return res.status(200).json({
      creator: 'dapjisync',
      success: true,
      message: j.message || 'Verifikasi berhasil! Akun Alight Motion telah aktif menjadi Premium 1 tahun.',
      email,
      data: {
        uid: j.uid || '-',
        orderId: j.orderId || '-',
        ownerMessage: ownerMessage || '',
        idToken: j.idToken || '-',
        valid: true
      }
    })
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message })
  }
}
