const BYPASS_KEY = 'amfree_key'
const AM_API = 'https://am.dapjisync.my.id'

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return res.status(200).end()
  if (req.method !== 'POST') return res.status(405).json({ success: false })

  const total = Math.min(5, Math.max(1, parseInt(req.body?.total || req.body?.count || 1)))

  try {
    const r = await fetch(`${AM_API}/api/bulk`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bypass-Key': BYPASS_KEY },
      body: JSON.stringify({ total })
    })
    const j = await r.json()
    return res.status(r.status).json({ creator: 'dapjisync', ...j })
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message })
  }
}
